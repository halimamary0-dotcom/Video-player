package com.vplayer.pro

import android.app.PictureInPictureParams
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var titleView: TextView
    private lateinit var feedback: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var prefs: SharedPreferences

    private var enhancer: LoudnessEnhancer? = null
    private var volumeLevel = 100 // من 0 إلى 300 بالمئة
    private var locked = false
    private var inPip = false
    private var resizeIdx = 0

    private val handler = Handler(Looper.getMainLooper())
    private val hideFeedback = Runnable { feedback.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val saveRunnable = object : Runnable {
        override fun run() {
            if (::player.isInitialized) saveProgress()
            handler.postDelayed(this, 5000)
        }
    }

    // حالة الإيماءات
    private var gestureMode = 0 // 0 لا شيء، 1 تقديم/تأخير، 2 سطوع، 3 صوت
    private var startBright = 0.5f
    private var startVol = 100
    private var startPos = 0L
    private var seekPreview = -1L
    private var longSpeed = false
    private var speedBeforeLong = 1f

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("ملائم للشاشة", "تمديد لملء الشاشة", "تكبير (قص الأطراف)")

    private val subLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) addSubtitle(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        prefs = getSharedPreferences("player", MODE_PRIVATE)

        playerView = findViewById(R.id.player_view)
        topBar = findViewById(R.id.top_bar)
        titleView = findViewById(R.id.title)
        feedback = findViewById(R.id.feedback)
        unlockBtn = findViewById(R.id.unlock_btn)

        setupImmersive()
        buildPlayer()
        setupTopBar()
        setupGestures()

        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (locked || inPip) View.GONE else vis
        })

        handler.postDelayed(saveRunnable, 5000)
    }

    // ---------------------------------------------------------------- المشغل

    private fun buildPlayer() {
        val items = mutableListOf<MediaItem>()
        var start = 0
        val data = intent?.data
        if (data != null) {
            items.add(mediaItemFor(data, queryName(data)))
        } else {
            VideoRepo.currentList.forEach { items.add(mediaItemFor(it.uri, it.name)) }
            start = intent.getIntExtra("index", 0).coerceIn(0, (items.size - 1).coerceAtLeast(0))
        }
        if (items.isEmpty()) {
            finish()
            return
        }

        player = ExoPlayer.Builder(this)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()
        playerView.player = player

        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(
                eventTime: AnalyticsListener.EventTime,
                audioSessionId: Int
            ) {
                setupEnhancer(audioSessionId)
            }
        })
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                titleView.text = mediaItem?.mediaMetadata?.title ?: ""
                if (mediaItem != null && reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) {
                    val p = savedPos(mediaItem.mediaId)
                    if (p > 0 && reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) player.seekTo(p)
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    player.currentMediaItem?.let { prefs.edit().remove("pos_${it.mediaId}").apply() }
                }
            }
        })

        volumeLevel = prefs.getInt("vol", 100)
        setupEnhancer(player.audioSessionId)
        applyVolume(volumeLevel)

        titleView.text = items[start].mediaMetadata.title ?: ""
        player.setMediaItems(items, start, savedPos(items[start].mediaId))
        player.prepare()
        player.playWhenReady = true
    }

    private fun mediaItemFor(uri: Uri, name: String): MediaItem =
        MediaItem.Builder()
            .setUri(uri)
            .setMediaId(uri.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
            .build()

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "فيديو"
    }

    private fun savedPos(id: String): Long {
        val p = prefs.getLong("pos_$id", 0L)
        return if (p > 3000) p else 0L
    }

    private fun saveProgress() {
        val item = player.currentMediaItem ?: return
        val dur = player.duration
        val pos = player.currentPosition
        val key = "pos_${item.mediaId}"
        if (dur > 0 && pos > 5000 && pos < dur - 5000) prefs.edit().putLong(key, pos).apply()
        else prefs.edit().remove(key).apply()
    }

    // ---------------------------------------------------------------- الصوت حتى 300٪

    private fun setupEnhancer(sessionId: Int) {
        try {
            enhancer?.release()
            enhancer = null
            if (sessionId != C.AUDIO_SESSION_ID_UNSET) {
                enhancer = LoudnessEnhancer(sessionId)
                applyVolume(volumeLevel)
            }
        } catch (e: Exception) {
            enhancer = null
        }
    }

    /**
     * 0..100  : مستوى صوت المشغل نفسه.
     * 101..300: يبقى المشغل على 100٪ ويُضاف تضخيم (LoudnessEnhancer).
     * 300٪ = ضرب السعة في 3 = 20*log10(3) ≈ 9.54 ديسيبل ≈ 954 ميلي-بل.
     */
    private fun applyVolume(level: Int) {
        volumeLevel = level.coerceIn(0, 300)
        player.volume = minOf(volumeLevel, 100) / 100f
        val gainMb = if (volumeLevel > 100) (2000.0 * log10(volumeLevel / 100.0)).toInt() else 0
        try {
            enhancer?.setTargetGain(gainMb)
            enhancer?.enabled = gainMb > 0
        } catch (_: Exception) {
        }
        prefs.edit().putInt("vol", volumeLevel).apply()
    }

    private fun showVolumeDialog() {
        val tv = TextView(this).apply {
            text = "$volumeLevel%"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val sb = SeekBar(this).apply {
            max = 300
            progress = volumeLevel
        }
        val note = TextView(this).apply {
            text = "فوق 100٪ يتم تضخيم الصوت، وقد يظهر تشويه عند المستويات العالية. ابدأ تدريجيًا لحماية السماعات وسمعك."
            textSize = 12f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
            addView(tv)
            addView(sb)
            addView(note)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    applyVolume(p)
                    tv.text = "$p%"
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        AlertDialog.Builder(this)
            .setTitle("مستوى الصوت")
            .setView(box)
            .setPositiveButton("تم", null)
            .show()
    }

    // ---------------------------------------------------------------- السطوع

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v.coerceIn(0.01f, 1f)
        window.attributes = lp
    }

    // ---------------------------------------------------------------- الإيماءات

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                startPos = player.currentPosition
                startVol = volumeLevel
                startBright = currentBrightness()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showUnlock()
                else if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = playerView.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000, "⏪ 10 ث")
                    e.x > w * 2f / 3f -> seekBy(10_000, "10 ث ⏩")
                    else -> if (player.isPlaying) player.pause() else player.play()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked) return
                longSpeed = true
                speedBeforeLong = player.playbackParameters.speed
                player.setPlaybackSpeed(2f)
                showFeedback("⏩ سرعة 2x (اترك الشاشة للعودة)")
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || longSpeed) return false
                val tx = e2.x - e1.x
                val ty = e2.y - e1.y
                if (gestureMode == 0) {
                    if (abs(tx) < 30 && abs(ty) < 30) return false
                    gestureMode = when {
                        abs(tx) > abs(ty) -> 1
                        e1.x < playerView.width / 2f -> 2
                        else -> 3
                    }
                }
                val h = playerView.height * 0.7f
                when (gestureMode) {
                    1 -> {
                        val dur = player.duration.coerceAtLeast(0)
                        seekPreview = (startPos + tx / playerView.width * 120_000).toLong().coerceIn(0, dur)
                        val diff = (seekPreview - startPos) / 1000
                        showFeedback("${fmtDuration(seekPreview)}   (${if (diff >= 0) "+" else "-"}${abs(diff)} ث)")
                    }
                    2 -> {
                        val v = (startBright - ty / h).coerceIn(0.01f, 1f)
                        setBrightness(v)
                        showFeedback("🔆 السطوع ${(v * 100).roundToInt()}%")
                    }
                    3 -> {
                        val lvl = (startVol - ty / h * 300f).roundToInt().coerceIn(0, 300)
                        applyVolume(lvl)
                        showFeedback("🔊 الصوت $lvl%" + if (lvl > 100) " (مُضخَّم)" else "")
                    }
                }
                return true
            }
        })

        playerView.setOnTouchListener { v, ev ->
            detector.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                if (longSpeed) {
                    longSpeed = false
                    player.setPlaybackSpeed(speedBeforeLong)
                }
                if (gestureMode == 1 && seekPreview >= 0) player.seekTo(seekPreview)
                gestureMode = 0
                seekPreview = -1
                handler.removeCallbacks(hideFeedback)
                handler.postDelayed(hideFeedback, 700)
                if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            }
            true
        }
    }

    private fun seekBy(ms: Long, msg: String) {
        val dur = player.duration.coerceAtLeast(0)
        player.seekTo((player.currentPosition + ms).coerceIn(0, dur))
        showFeedback(msg)
    }

    private fun showFeedback(text: String) {
        feedback.text = text
        feedback.visibility = View.VISIBLE
        handler.removeCallbacks(hideFeedback)
        handler.postDelayed(hideFeedback, 1200)
    }

    // ---------------------------------------------------------------- الشريط العلوي والأزرار

    private fun setupTopBar() {
        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<View>(R.id.btn_volume).setOnClickListener { showVolumeDialog() }
        findViewById<View>(R.id.btn_sub).setOnClickListener { subLauncher.launch(arrayOf("*/*")) }
        findViewById<View>(R.id.btn_lock).setOnClickListener { setLocked(true) }
        findViewById<View>(R.id.btn_rotate).setOnClickListener {
            requestedOrientation =
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        findViewById<View>(R.id.btn_aspect).setOnClickListener {
            resizeIdx = (resizeIdx + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIdx]
            showFeedback(resizeNames[resizeIdx])
        }
        findViewById<View>(R.id.btn_pip).setOnClickListener { enterPip() }
        unlockBtn.setOnClickListener { setLocked(false) }
    }

    private fun setLocked(value: Boolean) {
        locked = value
        if (value) {
            playerView.hideController()
            playerView.useController = false
            topBar.visibility = View.GONE
            showFeedback("🔒 الشاشة مقفلة — المس الشاشة ثم اضغط 🔓")
        } else {
            playerView.useController = true
            unlockBtn.visibility = View.GONE
            playerView.showController()
        }
    }

    private fun showUnlock() {
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
    }

    private fun addSubtitle(uri: Uri) {
        val name = queryName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val cur = player.currentMediaItem ?: return
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
        showFeedback("تمت إضافة الترجمة: ${queryName(uri)}")
    }

    // ---------------------------------------------------------------- نافذة عائمة (PiP)

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            Toast.makeText(this, "الجهاز لا يدعم النافذة العائمة", Toast.LENGTH_SHORT).show()
            return
        }
        val vs = player.videoSize
        val ratio = if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        val r = ratio.coerceIn(0.45f, 2.3f)
        enterPictureInPictureMode(
            PictureInPictureParams.Builder()
                .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                .build()
        )
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::player.isInitialized && player.isPlaying && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (inPip) {
            playerView.useController = false
            topBar.visibility = View.GONE
        } else if (!locked) {
            playerView.useController = true
        }
    }

    // ---------------------------------------------------------------- واجهة كاملة الشاشة ودورة الحياة

    private fun setupImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onStop() {
        super.onStop()
        if (::player.isInitialized) {
            saveProgress()
            player.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        enhancer?.release()
        enhancer = null
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
