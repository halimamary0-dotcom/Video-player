package com.vplayer.pro

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.util.Locale

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val folder: String,
    val durationMs: Long,
    val size: Long,
    val added: Long
)

object VideoRepo {
    /** قائمة التشغيل الحالية (تُمرَّر من الشاشة الرئيسية إلى المشغل داخل نفس العملية). */
    @Volatile
    var currentList: List<VideoItem> = emptyList()

    fun query(ctx: Context): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        ctx.contentResolver.query(base, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    VideoItem(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        name = c.getString(iName) ?: "video_$id",
                        folder = c.getString(iBucket) ?: "غير مصنف",
                        durationMs = c.getLong(iDur),
                        size = c.getLong(iSize),
                        added = c.getLong(iAdded)
                    )
                )
            }
        }
        return out
    }
}

fun fmtDuration(ms: Long): String {
    val s = (ms.coerceAtLeast(0)) / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

fun fmtSize(bytes: Long): String {
    var v = bytes.toDouble()
    val units = arrayOf("B", "KB", "MB", "GB")
    var i = 0
    while (v >= 1024 && i < units.lastIndex) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}
