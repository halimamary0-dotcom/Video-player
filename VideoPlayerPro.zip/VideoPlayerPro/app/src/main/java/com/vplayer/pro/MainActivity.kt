package com.vplayer.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var empty: TextView
    private val adapter = RowAdapter { onRow(it) }

    private var all: List<VideoItem> = emptyList()
    private var shownVideos: List<VideoItem> = emptyList()
    private var folder: String? = null
    private var query = ""
    private var sortMode = 0 // 0 = الأحدث، 1 = الاسم، 2 = الحجم

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            folder = null
            refresh()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) load() else showEmpty("لا يمكن عرض الفيديوهات بدون إذن الوصول للوسائط.")
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                startActivity(Intent(this, PlayerActivity::class.java).setData(uri))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        empty = findViewById(R.id.empty)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        onBackPressedDispatcher.addCallback(this, backCallback)
        ensurePermission()
    }

    private fun ensurePermission() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) load()
        else permLauncher.launch(perm)
    }

    private fun load() {
        thread {
            val list = try { VideoRepo.query(this) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                all = list
                refresh()
            }
        }
    }

    private fun refresh() {
        val filtered = if (query.isBlank()) all else all.filter { it.name.contains(query, true) }
        val sorted = when (sortMode) {
            1 -> filtered.sortedBy { it.name.lowercase() }
            2 -> filtered.sortedByDescending { it.size }
            else -> filtered.sortedByDescending { it.added }
        }
        val rows: List<Row>
        if (folder == null && query.isBlank()) {
            rows = sorted.groupBy { it.folder }
                .map { (name, list) -> Row.Folder(name, list.size, list.first().uri) }
                .sortedBy { it.name.lowercase() }
            shownVideos = emptyList()
        } else {
            shownVideos = sorted.filter { folder == null || it.folder == folder }
            rows = shownVideos.map { Row.Video(it) }
        }
        adapter.submit(rows)
        supportActionBar?.title = folder ?: "مشغل الفيديو"
        backCallback.isEnabled = folder != null
        if (rows.isEmpty()) showEmpty("لا توجد فيديوهات.") else empty.visibility = View.GONE
    }

    private fun showEmpty(msg: String) {
        empty.text = msg
        empty.visibility = View.VISIBLE
    }

    private fun onRow(r: Row) {
        when (r) {
            is Row.Folder -> {
                folder = r.name
                refresh()
            }
            is Row.Video -> {
                VideoRepo.currentList = shownVideos
                val idx = shownVideos.indexOf(r.item).coerceAtLeast(0)
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", idx))
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        val sv = menu.findItem(R.id.action_search).actionView as SearchView
        sv.queryHint = "بحث عن فيديو"
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                query = newText ?: ""
                refresh()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.sort_date -> sortMode = 0
            R.id.sort_name -> sortMode = 1
            R.id.sort_size -> sortMode = 2
            R.id.action_open -> {
                pickLauncher.launch(arrayOf("video/*", "application/octet-stream"))
                return true
            }
            R.id.action_refresh -> {
                load()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
        refresh()
        return true
    }
}
