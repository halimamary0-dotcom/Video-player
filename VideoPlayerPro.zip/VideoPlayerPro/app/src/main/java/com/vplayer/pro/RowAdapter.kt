package com.vplayer.pro

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

sealed class Row {
    data class Folder(val name: String, val count: Int, val thumb: Uri) : Row()
    data class Video(val item: VideoItem) : Row()
}

class RowAdapter(private val onClick: (Row) -> Unit) : RecyclerView.Adapter<RowAdapter.VH>() {

    private var rows: List<Row> = emptyList()

    fun submit(list: List<Row>) {
        rows = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        when (r) {
            is Row.Folder -> {
                h.title.text = "📁 ${r.name}"
                h.sub.text = "${r.count} فيديو"
                Glide.with(h.thumb).load(r.thumb).centerCrop().into(h.thumb)
            }
            is Row.Video -> {
                h.title.text = r.item.name
                h.sub.text = "${fmtDuration(r.item.durationMs)} • ${fmtSize(r.item.size)}"
                Glide.with(h.thumb).load(r.item.uri).centerCrop().into(h.thumb)
            }
        }
        h.itemView.setOnClickListener { onClick(r) }
    }
}
